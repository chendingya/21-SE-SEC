# VJVM
VJVM: Virtual Java Virtual Machine (toy)
