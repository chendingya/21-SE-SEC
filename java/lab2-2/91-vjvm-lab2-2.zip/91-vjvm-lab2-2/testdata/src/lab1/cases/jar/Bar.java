package lab1.cases.jar;

class Bar {}
