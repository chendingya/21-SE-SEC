package lab2;

public class HelloWorld {
  public static void main(String[] args) {
    IOUtil.writeChar('H');
    IOUtil.writeChar('e');
    IOUtil.writeChar('l');
    IOUtil.writeChar('l');
    IOUtil.writeChar('o');
    IOUtil.writeChar(',');
    IOUtil.writeChar(' ');
    IOUtil.writeChar('W');
    IOUtil.writeChar('o');
    IOUtil.writeChar('r');
    IOUtil.writeInt(1);
    IOUtil.writeChar('d');
  }
}
